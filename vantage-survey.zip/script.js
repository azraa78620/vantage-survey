document.addEventListener('DOMContentLoaded', function () {
  const y = new Date().getFullYear();
  document.getElementById('year').textContent = y;
  const navToggle = document.getElementById('navToggle');
  const primaryNav = document.getElementById('primaryNav');
  navToggle.addEventListener('click', function () {
    const isOpen = primaryNav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });
});
